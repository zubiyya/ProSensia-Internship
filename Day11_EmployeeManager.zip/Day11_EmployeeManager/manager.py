from employee import Employee
import os

class EmployeeManager:
    def __init__(self, filename="employee_data.txt"):
        self.filename = filename
        self.employees = []
        self.load_data()

    def load_data(self):
        if not os.path.exists(self.filename):
            return
        with open(self.filename, "r") as f:
            for line in f:
                self.employees.append(Employee.from_line(line))

    def save_data(self):
        with open(self.filename, "w") as f:
            for emp in self.employees:
                f.write(emp.to_line() + "\n")

    def add_employee(self, name, dept, salary, year):
        emp = Employee(name, dept, salary, year)
        self.employees.append(emp)

    def list_employees(self):
        if not self.employees:
            print("No employees found.")
        for emp in self.employees:
            emp.display()

    def search_employee(self, term):
        result = list(filter(lambda e: term.lower() in e.name.lower() or term.lower() in e.department.lower(), self.employees))
        for emp in result:
            emp.display()

    def sort_by_salary(self, desc=False):
        sorted_emps = sorted(self.employees, key=lambda e: e.salary, reverse=desc)
        for emp in sorted_emps:
            emp.display()

    def generate_report(self, report_file="employee_report.txt"):
        with open(report_file, "w") as f:
            f.write(f"Total Employees: {len(self.employees)}\n")
            if self.employees:
                highest = max(self.employees, key=lambda e: e.salary)
                lowest = min(self.employees, key=lambda e: e.salary)
                avg_salary = sum(e.salary for e in self.employees) / len(self.employees)
                f.write(f"Highest Salary: {highest.salary} - {highest.name}\n")
                f.write(f"Lowest Salary: {lowest.salary} - {lowest.name}\n")
                f.write(f"Average Salary: {avg_salary:.2f}\n")
        print("Report generated successfully.")
