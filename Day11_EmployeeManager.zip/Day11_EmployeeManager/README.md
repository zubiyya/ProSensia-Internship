# Day 11 – Employee Record System

A Python-based employee manager using:
- OOP (Employee, Manager)
- File handling (Save/Load from TXT)
- Lambda + sorting
- CLI menu

## Features:
- Add, List, Search, Sort employees
- Generate summary report
- Handles input errors

## Author: Zubia Tanoli
#ProSensiaInternship
