from manager import EmployeeManager
from utils import input_float, input_int

def main():
    manager = EmployeeManager()

    while True:
        print("\n--- Employee Management Menu ---")
        print("1. Add Employee")
        print("2. List Employees")
        print("3. Search by Name/Department")
        print("4. Sort by Salary")
        print("5. Generate Report")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            name = input("Enter name: ")
            dept = input("Enter department: ")
            salary = input_float("Enter salary: ")
            year = input_int("Enter joining year: ")
            manager.add_employee(name, dept, salary, year)
            print("Employee added.")

        elif choice == "2":
            manager.list_employees()

        elif choice == "3":
            term = input("Enter name or department to search: ")
            manager.search_employee(term)

        elif choice == "4":
            order = input("Sort by salary descending? (y/n): ").lower() == "y"
            manager.sort_by_salary(desc=order)

        elif choice == "5":
            manager.generate_report()

        elif choice == "6":
            manager.save_data()
            print("Data saved. Exiting...")
            break

        else:
            print("Invalid choice! Try again.")

if __name__ == "__main__":
    main()
