
# 📊 Data Visualization with Python – Charts, Graphs & Insights

This project demonstrates how to visualize data using Python libraries like **matplotlib**, **seaborn**, and **pandas**.

## 📁 Dataset
- `sales.csv`: Monthly sales data for three products and overall revenue.

## 📈 Visualizations
- **Line Chart**: Monthly Revenue
- **Bar Chart**: Product Sales Comparison
- **Pie Chart**: Market Share (Latest Month)
- **Heatmap**: Correlation between features

## 📝 Summary Report
- Includes average revenue, highest revenue month, and correlation matrix.

## 🚀 How to Run
1. Make sure `sales.csv` is in your directory.
2. Run the script:  
```bash
python data_visualization.py
```

3. Output files will be saved as:
   - `Line_Chart.png`
   - `Bar_Chart.png`
   - `Pie_Chart.png`
   - `Heatmap.png`
   - `Summary_Report.txt`
