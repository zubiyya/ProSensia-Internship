
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load CSV
df = pd.read_csv('sales.csv')
df.dropna(inplace=True)

# Line Chart
plt.figure(figsize=(10, 5))
plt.plot(df['Month'], df['Total_Revenue'], marker='o', color='green')
plt.title('Monthly Revenue')
plt.xlabel('Month')
plt.ylabel('Revenue')
plt.grid(True)
plt.savefig('Line_Chart.png')
plt.close()

# Bar Chart
plt.figure(figsize=(10, 6))
product_sales = df[['Product_A', 'Product_B', 'Product_C']]
product_sales.plot(kind='bar')
plt.title('Monthly Product Sales')
plt.xlabel('Index')
plt.ylabel('Units Sold')
plt.xticks(ticks=range(len(df)), labels=df['Month'], rotation=0)
plt.tight_layout()
plt.savefig('Bar_Chart.png')
plt.close()

# Pie Chart (Last Month)
last_row = df.iloc[-1]
labels = ['Product A', 'Product B', 'Product C']
sizes = [last_row['Product_A'], last_row['Product_B'], last_row['Product_C']]
colors = ['skyblue', 'orange', 'lightgreen']
plt.figure(figsize=(6, 6))
plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
plt.title('Market Share Distribution (Last Month)')
plt.savefig('Pie_Chart.png')
plt.close()

# Heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm')
plt.title('Feature Correlation Heatmap')
plt.savefig('Heatmap.png')
plt.close()

# Summary Report
with open('Summary_Report.txt', 'w') as report:
    report.write("📊 Summary Report - Sales Data Analysis\n")
    report.write("="*50 + "\n\n")
    report.write("Top-Level Overview:\n")
    report.write(f"Total Rows: {len(df)}\n")
    report.write(f"Columns: {', '.join(df.columns)}\n\n")
    report.write("Average Monthly Revenue: " + str(df['Total_Revenue'].mean()) + "\n")
    report.write("Highest Revenue Month: " + df.loc[df['Total_Revenue'].idxmax(), 'Month'] + "\n")
    report.write("Correlation Matrix:\n")
    report.write(df.corr(numeric_only=True).to_string())
